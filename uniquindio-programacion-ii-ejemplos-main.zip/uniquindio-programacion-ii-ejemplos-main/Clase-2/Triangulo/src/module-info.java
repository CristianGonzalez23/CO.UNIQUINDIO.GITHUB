module Triangulo {
}